function OnStoredInstance(instanceId, tags, metadata)
    SendToModality(instanceId, 'hippoai')
 end
 